<!DOCTYPE html>
    <html>
    <head>
        <title>Abdul</title>
        <style>
            .card2 {
                list-style: none;
                width: 200px;
                padding: 10px;
                margin: 10px;
                border: 1px solid #ccc;
                float: left;
                text-align: center;
            }
            .img img {
                width: 150px;
                height: 200px;
                object-fit: cover;
            }
        </style>
    </head>
    <body>
        <ul>
            <li class="card2">
                <a href="./Daftarbuku/Promo/wallpaper.jpg">
                    <div class="img">
                        <img src="./Daftarbuku/Promo/wallpaper.jpg" alt="Book Image">
                    </div>
                    <h2>Abdul</h2>
                    <p>ZeroTwo</p>
                    <span>123456</span>
                </a>
            </li>
        </ul>
    </body>
    </html>